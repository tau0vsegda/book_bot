<?php

namespace Telegram\Bot\Objects;

/**
 * Class Object.
 */
class TelegramObject extends BaseObject
{
    /**
     * Property relations.
     *
     * @return array
     */
    public function relations()
    {
        return [];
    }
}
